// File name: ...\s13\02_documentation\main.go
// Course Name: Go (Golang) Programming by Example (by Kam Hojati)

package main

import (
	"fmt"

	"./shapes1"
)

func main() {
	fmt.Printf("shape1 pkg - Rectangle Area= %d\n", shapes1.Area(2, 3))
}
