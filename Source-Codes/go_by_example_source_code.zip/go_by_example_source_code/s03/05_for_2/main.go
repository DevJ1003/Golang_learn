// File name: ...\s03\05_for_2\main.go
// Course Name: Go (Golang) Programming by Example (by Kam Hojati)

package main

import "fmt"

func main() {
	for i := 2; i < 5; i++ {
		fmt.Println(i, i*10)
	}

}
